export const USER_ROLES = ['supper_admin','customer','vendor','audit','admin']

export const USER_PRIVILLAGES = {
    "supper_admin":['create','update','delete','view'],
    "customer":['view'],
    "vendor":['create','view'],
    "audit":['update','view'],
    "admin":['create','update','view']
}

