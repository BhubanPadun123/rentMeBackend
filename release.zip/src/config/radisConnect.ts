import {createClient} from "redis"


const RadisCline = createClient()

RadisCline.on('error',(err)=> console.log('Redis Client Error', err))

const Rconnect = async()=>{
    await RadisCline.connect()
}

export {
    RadisCline
}

export default Rconnect
